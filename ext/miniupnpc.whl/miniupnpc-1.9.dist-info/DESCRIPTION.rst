Copyright (c) 2005-2011, Thomas BERNARD
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * The name of the author may not be used to endorse or promote products
	  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.


Description: this is just a repack of the original `miniupnp` project to facilitate install
        `miniupnpc` by pypi
        
        -----------original readme----------
        
        Project: miniupnp
        Project web page: http://miniupnp.free.fr/ or http://miniupnp.tuxfamily.org/
        github: https://github.com/miniupnp/miniupnp
        freecode: http://freecode.com/projects/miniupnp
        Author: Thomas Bernard
        Copyright (c) 2005-2012 Thomas Bernard
        This software is subject to the conditions detailed in the
        LICENSE file provided within this distribution.
        
        
        For the comfort of Win32 users, bsdqueue.h is included in the distribution.
        Its licence is included in the header of the file.
        bsdqueue.h is a copy of the sys/queue.h of an OpenBSD system.
        
        
        * miniUPnP Client - miniUPnPc *
        
        To compile, simply run 'gmake' (could be 'make' on your system).
        Under win32, to compile with MinGW, type "mingw32make.bat".
        MS Visual C solution and project files are supplied in the msvc/ subdirectory.
        
        The compilation is known to work under linux, FreeBSD,
        OpenBSD, MacOS X, AmigaOS and cygwin.
        The official AmigaOS4.1 SDK was used for AmigaOS4 and GeekGadgets for AmigaOS3.
        upx (http://upx.sourceforge.net) is used to compress the win32 .exe files.
        
        To install the library and headers on the system use :
        > su
        > make install
        > exit
        
        alternatively, to install into a specific location, use :
        > INSTALLPREFIX=/usr/local make install
        
        upnpc.c is a sample client using the libminiupnpc.
        To use the libminiupnpc in your application, link it with
        libminiupnpc.a (or .so) and use the following functions found in miniupnpc.h,
        upnpcommands.h and miniwget.h :
        - upnpDiscover()
        - miniwget()
        - parserootdesc()
        - GetUPNPUrls()
        - UPNP_* (calling UPNP methods)
        
        Note : use #include <miniupnpc/miniupnpc.h> etc... for the includes
        and -lminiupnpc for the link
        
        Discovery process is speeded up when MiniSSDPd is running on the machine.
        
        
        * Python module *
        
        you can build a python module with 'make pythonmodule'
        and install it with 'make installpythonmodule'.
        setup.py (and setupmingw32.py) are included in the distribution.
        
        
        Feel free to contact me if you have any problem :
        e-mail : miniupnp@free.fr
        
        If you are using libminiupnpc in your application, please
        send me an email !
        
        For any question, you can use the web forum :
        http://miniupnp.tuxfamily.org/forum/
        
        
Platform: UNKNOWN
